/**
 * productsService
 *
 * Talks exclusively to the real Laravel backend.
 *
 * Endpoints used:
 *   GET    /products?page=&per_page=&q=&category=&sort=
 *   GET    /products/{id}
 *   GET    /products/featured?limit=
 *   POST   /products          { name, description, price, category }
 *   PUT    /products/{id}     { name, description, price, category }
 *   POST   /products/{id}/image  (multipart, separate upload)
 *   DELETE /products/{id}
 *
 * Laravel ProductResource shape:
 *   { id, name, description, price (string), category, image_url, stock_quantity, created_at, updated_at }
 */

import { apiClient } from '@/shared/lib/apiClient'
import type { PaginatedResponse } from '@/shared/types/api.types'
import type {
  Product,
  ProductInput,
  ProductPageResult,
  ProductQuery,
} from '../types/product.types'

// ─── Backend DTO ──────────────────────────────────────────────────────────────
interface ProductDto {
  id: number
  name: string
  description: string | null
  price: string | number
  category: string
  image_url: string | null
  stock_quantity: number | null
  created_at: string | null
  updated_at?: string | null
}

interface ProductDtoEnvelope {
  data: ProductDto
}

// ─── Sort mapping: frontend key → Laravel `sort` param ───────────────────────
// Laravel ProductController: sort=name → ASC, sort=-price → DESC price, etc.
function toApiSort(sort: string): string | undefined {
  switch (sort) {
    case 'price-asc': return 'price'
    case 'price-desc': return '-price'
    case 'name': return 'name'
    // 'featured' is not a real column — rely on Laravel's default (-created_at)
    default: return undefined
  }
}

function mapProduct(d: ProductDto): Product {
  const stock = d.stock_quantity ?? 0
  return {
    id: d.id,
    name: d.name,
    description: d.description ?? '',
    price: Number(d.price),
    category: d.category,
    image: d.image_url ?? '',
    stock,
    availability:
      d.stock_quantity === null
        ? undefined
        : stock === 0
          ? 'Out of stock'
          : stock <= 5
            ? 'Low stock'
            : 'In stock',
    createdAt: d.created_at ?? new Date().toISOString(),
  }
}

function toPayload(input: ProductInput) {
  return {
    name: input.name,
    description: input.description,
    price: input.price,
    category: input.category,
  }
}

// ─── Public API ───────────────────────────────────────────────────────────────

async function list(query: ProductQuery): Promise<ProductPageResult> {
  const { search, category, sort } = query.filters
  const res = await apiClient.get<PaginatedResponse<ProductDto>>('/products', {
    params: {
      page: query.page,
      per_page: query.perPage,
      q: search || undefined,
      category: category === 'All' ? undefined : category || undefined,
      sort: toApiSort(sort),
    },
  })
  return {
    items: res.data.map(mapProduct),
    total: res.meta.total,
    page: res.meta.current_page,
    perPage: res.meta.per_page,
    totalPages: Math.max(1, res.meta.last_page),
  }
}

async function getById(id: number): Promise<Product | null> {
  try {
    const res = await apiClient.get<ProductDtoEnvelope>(`/products/${id}`)
    return mapProduct(res.data)
  } catch (e) {
    if ((e as { status?: number }).status === 404) return null
    throw e
  }
}

async function getFeatured(limit = 4): Promise<Product[]> {
  // Laravel returns a collection: { data: ProductDto[] }
  const res = await apiClient.get<{ data: ProductDto[] }>('/products/featured', {
    params: { limit },
  })
  return res.data.map(mapProduct)
}

async function create(input: ProductInput): Promise<Product> {
  const res = await apiClient.post<ProductDtoEnvelope>('/products', toPayload(input))
  return mapProduct(res.data)
}

async function update(id: number, input: ProductInput): Promise<Product> {
  const res = await apiClient.put<ProductDtoEnvelope>(`/products/${id}`, toPayload(input))
  return mapProduct(res.data)
}

async function remove(id: number): Promise<void> {
  await apiClient.delete<void>(`/products/${id}`)
}

export const productsService = {
  list,
  getById,
  getFeatured,
  create,
  update,
  remove,
} as const

/**
 * useBackendCategories
 *
 * Fetches the distinct category values from the live product database by
 * requesting page 1 with a large per_page and extracting unique categories.
 *
 * This avoids a dedicated /categories endpoint (which doesn't exist in the
 * Laravel API) while still reflecting real database values.
 *
 * Falls back to the hardcoded PRODUCT_CATEGORIES constant if the fetch fails.
 */
import { useEffect, useState } from 'react'
import { apiClient } from '@/shared/lib/apiClient'
import { PRODUCT_CATEGORIES } from '../types/product.types'

interface ProductDtoMin {
  category: string
}

interface ProductListResponse {
  data: ProductDtoMin[]
}

export function useBackendCategories() {
  const [categories, setCategories] = useState<string[]>(PRODUCT_CATEGORIES)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let cancelled = false
    apiClient
      .get<ProductListResponse>('/products', { params: { per_page: 200, page: 1 } })
      .then((res) => {
        if (cancelled) return
        const unique = Array.from(
          new Set(res.data.map((p) => p.category).filter(Boolean))
        ).sort()
        if (unique.length > 0) setCategories(unique)
      })
      .catch(() => {
        // silently fall back to hardcoded list
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => { cancelled = true }
  }, [])

  return { categories, loading }
}
